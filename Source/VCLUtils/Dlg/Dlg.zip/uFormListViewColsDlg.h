//---------------------------------------------------------------------------

#ifndef uFormListViewColsDlgH
#define uFormListViewColsDlgH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <CheckLst.hpp>
#include <ExtCtrls.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
class TFormListviewColsDlg : public TForm
{
__published:	// IDE-managed Components
	TCheckListBox *clb;
	void __fastcall clbClickCheck(TObject *Sender);
	void __fastcall clbKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
private:	// User declarations
	TListView& lv_;
    unsigned Count_(){ return lv_.Columns->Count; }

public:		// User declarations
	__fastcall TFormListviewColsDlg(TListView& lv, TComponent* Owner = NULL);
};
//---------------------------------------------------------------------------
extern PACKAGE TFormListviewColsDlg *FormListviewColsDlg;
//---------------------------------------------------------------------------
#endif
