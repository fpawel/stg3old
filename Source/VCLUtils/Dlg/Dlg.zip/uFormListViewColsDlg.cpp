//---------------------------------------------------------------------------
#include "hromat900_pch.h"
#pragma hdrstop

#include "uFormListViewColsDlg.h"
#include "listViewHelpr_.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFormListviewColsDlg *FormListviewColsDlg;
//---------------------------------------------------------------------------
__fastcall TFormListviewColsDlg::TFormListviewColsDlg( TListView& lv, TComponent* Owner)
	: TForm(Owner), lv_(lv)
{
    clb->Items->Clear();
	for( int i=0; i<lv_.Columns->Count; ++i)
        clb->Items->Add( lv_.Column[i]->Caption );

    clb->Items->Add("�������� ���");
    clb->ItemEnabled[0] = 0;
    Height = 100 + clb->ItemHeight*clb->Count;
    Width = 100 + Canvas->TextWidth(Caption);

	for( unsigned cl=0; cl<Count_(); ++cl )
    	clb->Checked[cl] = Lv::GetColVis( &lv_, cl );

    Caption = "�������� ������� ������� �������";
    //SetVis_(0, 1);

}
//---------------------------------------------------------------------------
void __fastcall TFormListviewColsDlg::clbClickCheck(TObject *Sender)
{
	const int idx = clb->ItemIndex, cnt = clb->Count - 1;
    if( idx>-1 && idx<cnt )
        Lv::SetColVis( &lv_, idx, clb->Checked[idx] );
    if( idx==cnt ) for( int i=1; i<cnt; ++i )
    {
    	clb->Checked[i] = clb->Checked[idx];
    	Lv::SetColVis( &lv_, i, clb->Checked[idx] );
    }


}
//---------------------------------------------------------------------------


void __fastcall TFormListviewColsDlg::clbKeyDown(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
	if( Key==VK_ESCAPE || Key==VK_RETURN)
    	Close();	
}
//---------------------------------------------------------------------------

